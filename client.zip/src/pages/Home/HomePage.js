// HomePage.js

import React, { useState } from 'react';
import './HomePage.css';
import Header from '../../components/Header/Header';
import Sidebar from '../../components/Sidebar/Sidebar';
import Main from '../../components/Main/Main';
import Footer from '../../components/Footer/Footer';
import EditContract from '../../components/EditContract/EditContract';
import { Link, useNavigate } from 'react-router-dom';

const HomePage = () => {
  // const [selectedTabContent, setSelectedTabContent] = useState('');
  const navigate = useNavigate();
  // const handleTabClick = (tab) => {
  //   // Handle tab click logic, you can update the state or fetch data here
  //   setSelectedTabContent(`Data for ${tab}`);
  // };

  const [selectedTab, setSelectedTab] = useState('contracts');

  const handleTabClick = (tab) => {
    setSelectedTab(tab);
  };

  const handleEditButtonClick = (id) => {
    // console.log(e);
    console.log(id);
    // Handle button click logic
    // Navigate to the desired page or update content in the same component
    // navigate(`/edit/:{id}`);
  };

  return (
    // <div className="app">
    //   <Header />
    //   <div className="content-container">
    //     <Sidebar onTabClick={handleTabClick} />
    //     <Main selectedTab={selectedTab} />
    //   </div>
    //   <Footer />
    // </div>
    <div>
      {/* <Header /> */}
      {/* <Sidebar onTabClick={handleTabClick} /> */}
      {/* <Main selectedTab={selectedTab} onEditButtonClick={handleEditButtonClick}/> */}
      {/* <Footer /> */}
    </div>
  );
}

export default HomePage;
