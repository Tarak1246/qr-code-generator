import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate, Switch } from 'react-router-dom';
import LoginPage from './components/Login/LoginPage';
import HomePage from './pages/Home/HomePage';
import EditContract from './components/EditContract/EditContract';
import './App.css';
import Layout from './components/Layout/Layout';
import Main from './components/Main/Main';
import { DataProvider } from './components/DataContext';
import AddContract from './components/AddContract/AddContract';

const App = () => {
  // let routes = useRoutes([
  //   { path: "/", element: <Component1 /> },
  //   { path: "component2", element: <Component2 /> },
  //   // ...
  // ]);
  // return routes;
  return (
    /* <Router>
       <div className="app-container">
         <div className="content-container">
           <Routes>
             <Route path="/">
               <Route index element={<Navigate to="/login" replace />} />
               <Route path="/login" element={<LoginPage />} />
               <Route path="/home" element={<HomePage />} />
               <Route path="/edit/:id" element={<EditContract />} />
             </Route>
           </Routes>
         </div>
       </div>
     </Router>*/

    <Router>
      <DataProvider>
        <Routes>
          <Route
            path="/*"
            element={
              <Layout>
                <Routes>
                  <Route index element={<Navigate to="/login" replace />} />
                  <Route path="/main" element={<Main />} />
                  <Route path="/editContract/:id" element={<EditContract />} />
                  <Route path="/addContract" element={<AddContract />} />
                </Routes>
              </Layout>
            }
          />
          <Route path="/login" element={<LoginPage />} />
        </Routes>
      </DataProvider>
    </Router>

    // <Router>
    //   <Routes>
    //       <Route path="/">
    //         <Route index element={<Navigate to="/login" replace />} />
    //         <Route path="/login" element={<LoginPage />} />
    //         <Route path="/home" element={<HomePage />} />
    //         <Route path="/edit/:id" element={<EditContract />} />
    //         {/* <Route path="/createForm" element={<Main />} /> */}
    //         {/* <Route path="pathB" element={<ComponentB />} />
    //     <Route path="pathC" element={<ComponentC />} /> */}
    //       </Route>
    //   </Routes>
    // </Router>
  );
}

export default App;