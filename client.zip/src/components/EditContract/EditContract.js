// EditPage.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useData } from '../DataContext';
import './EditContract.css';
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useAsyncDebounce } from 'react-table';

const EditPage = () => {
  toast.configure();
  const { id } = useParams();
  const navigate = useNavigate();
  const { state } = useData();//JSON.stringify(state.data)
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        // const response = await axios.get(`your-api-endpoint/${id}`);
        console.log(JSON.stringify(state))
        // let response = {
        //   "data": [
        //     {
        //       "id": 1,
        //       "name": "John Doe",
        //       "age": 30,
        //       "email": "john@example.com"
        //     },
        //     {
        //       "id": 2,
        //       "name": "Jane Smith",
        //       "age": 25,
        //       "email": "jane@example.com"
        //     },
        //   ]
        // }
        setFormData(state.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching item for edit:', error);
      }
    };

    fetchData();
  }, [id]);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    console.log(name,value);
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    console.log(formData)
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      // Make PUT request to update item in the database
      // await axios.put(`your-api-endpoint/${id}`, formData);
      // Redirect or navigate back to the main page after successful update
      // You can use a library like react-router-dom for navigation
      navigate('/home');
    } catch (error) {
      console.error('Error updating item:', error);
    }
  };

  const cancelForm = async (e) => {
    try {
      // Make PUT request to update item in the database
      // await axios.put(`your-api-endpoint/${id}`, formData);
      // Redirect or navigate back to the main page after successful update
      // You can use a library like react-router-dom for navigation
      navigate('/home');
    } catch (error) {
      console.error('Error cancelling contract:', error);
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <h2>Edit Contract</h2>
      <form className="dynamic-form" onSubmit={handleFormSubmit}>
      {Object.keys(formData).map((field) => (
        <div key={field} className="form-group">
          <label htmlFor={field}>{field}</label>
          <input
            type="text"
            id={field}
            name={field}
            className="form-control"
            value={formData[field]}
            onChange={handleFormChange}
          />
        </div>
      ))}
      <button type="submit" className="btn btn-primary">
        Submit
      </button>
      <button className="btn btn-primary" onClick={() => cancelForm()}>
        Cancel
      </button>
    </form>
    </div>
  );
};

export default EditPage;
