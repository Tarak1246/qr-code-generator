// Main.js
import React, { useState, useEffect } from 'react';
import './Main.css';
import { getContracts } from '../../services/api';
import { Link, useNavigate } from 'react-router-dom';
import { useData } from '../DataContext';
import ConfirmToast from '../ConfirmToast/ConfirmToast';
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Dashboard from '../Dashboard/Dashboard';
import Contracts from '../Contracts/Contracts';

const Main = ({ selectedTab }) => {
  toast.configure();
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const { state, setDataa } = useData();
  let content;

  useEffect(() => {
    const fetchData = async () => {
      try {
        // const response = await getContracts();
        let response = {
          "data": [
            {
              "id": 1,
              "name": "John Doe",
              "age": 30,
              "email": "john@example.com"
            },
            {
              "id": 2,
              "name": "Jane Smith",
              "age": 25,
              "email": "jane@example.com"
            },
          ]
        };
        setData(response.data); // Assuming the response is an array of data
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData(); // Call the function on component mount
  }, []); // The empty dependency array ensures it runs only once on mount

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  // Filtering data based on the search term
  const filteredData = data.filter((item) =>
    // item.name.toLowerCase().includes(searchTerm.toLowerCase())
    // Check if any property contains the search term
    Object.values(item).some((value) =>
      String(value).toLowerCase().includes(searchTerm)
    )
  );

  // Dynamic headers based on keys of the first item in data
  const tableHeaders = data.length > 0 ? Object.keys(data[0]) : [];

  const handleDeleteClick = () => {
    let toastId; // Declare toastId variable

    const handleConfirm = () => {
      // Handle the delete action here
      console.log('Item deleted!');
      toast.success('Item deleted!', {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 10000
      });
      toast.dismiss(toastId); // Close the confirmation toast
      navigate('/home');
    };

    // Show confirmation toast and capture toastId
    toastId = toast.warning(<ConfirmToast onConfirm={handleConfirm} />, {
      autoClose: false,
      closeButton: true,
    });
  };


  const handleConfirm = () => {
    // Handle the delete action here
    console.log('Item deleted!');
    toast.success('Item deleted successfully!');
  };

  const handleDelete = async (id) => {
    toast(<ConfirmToast onConfirm={handleConfirm} />, {
      autoClose: false,
      closeButton: true,
      // position: toast.POSITION.TOP_CENTER
    });
    // const shouldDelete = window.confirm('Are you sure you want to delete this item?');

    // if (shouldDelete) {
    //   try {
    //     // Make DELETE request to delete item from the database
    //     // await axios.delete(`your-api-endpoint/${id}`);
    //     // Update the local state (remove the deleted item)
    const updatedData = data.filter((item) => item.id !== id);
    setData(updatedData);
    //     // navigate('/home')
    //   } catch (error) {
    //     console.error('Error deleting item:', error);
    //   }
    // }
  };

  const handleEditClick = (item) => {
    console.log(item)
    // Call the provided callback to handle the edit button click
    // onEditButtonClick();
    setDataa(item);
    // Navigate to the edit page
    navigate(`/editContract/${item.id}`);

  };
  
  const addContract = async (e) => {
    try {
      navigate('/addContract');
    } catch (error) {
      console.error('Error cancelling contract:', error);
    }
  };

  switch (selectedTab) {

    case 'dashboard':
      content = <div className="my-component-container"><Dashboard /></div>
      break;
    case 'contracts':
      content = <div className="my-component-container"><Contracts /></div>
      break;
    case 'advisors':
      content = <div>This is {selectedTab}</div>
    default:
      content = <div>This is the default variant</div>;
  }

  return (
    <main style={{ paddingLeft: '209px', flex: '1', backgroundColor: '#fff' }}>
      {content}
    </main>
  );
};

export default Main;
