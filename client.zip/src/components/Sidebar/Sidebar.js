// Sidebar.js
import React, { useState, useEffect } from 'react';
import './Sidebar.css';
// import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
// import { Link, useNavigate } from 'react-router-dom';


const Sidebar = ({ onTabClick }) => {
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleTabClick = (tab) => {
    onTabClick(tab);
    // setActiveTab(tab);
  };


  return (
    <aside style={{position:'fixed',overflowY:'hidden',top:'52px',bottom:0}}>
      <div onClick={() => onTabClick('dashboard')}>
        Dashboard
      </div>
      <div onClick={() => {onTabClick('contracts');}}>
        Contracts
      </div>
      <div onClick={() => onTabClick('projects')}>
        Projects
      </div>
      <div onClick={() => onTabClick('advisors')}>
        Advisors
      </div>
    </aside>
  //   <aside style={{ position: 'fixed', overflowY: 'hidden', top: '52px', bottom: 0 }}>
  //   <div onClick={() => onTabClick('dashboard')} style={{ backgroundColor: activeTab === 'dashboard' ? 'lightblue' : 'white' }}>
  //     Dashboard
  //   </div>
  //   <div onClick={() => onTabClick('contracts')} style={{ backgroundColor: activeTab === 'contracts' ? 'lightblue' : 'white' }}>
  //     Contracts
  //   </div>
  //   <div onClick={() => onTabClick('projects')} style={{ backgroundColor: activeTab === 'projects' ? 'lightblue' : 'white' }}>
  //     Projects
  //   </div>
  //   <div onClick={() => onTabClick('advisors')} style={{ backgroundColor: activeTab === 'advisors' ? 'lightblue' : 'white' }}>
  //     Advisors
  //   </div>
  // </aside>
    //navigate('/createForm')
        // <Router>
    //   <Routes>
    //     {/* <div style={{ display: 'flex' }}>        
    //       <div style={{ flex: 1, padding: '10px' }}>
    //         <Route path="/" exact component={Home} />
    //         <Route path="/tab1" component={Tab1} />
    //         <Route path="/tab2" component={Tab2} />
    //         <Route path="/tab3" component={Tab3} />
    //       </div>
    //     </div> */}
    //     <Route path="/" element={<LoginPage />} >        
    //       <Route path="/login" element={<LoginPage />} />
    //       <Route path="/home" element={<HomePage />} />
    //     {/* <Route path="*" element={<NoPage />} />  */}
    //     </Route>
    //   </Routes>
    // </Router>
  );
};

export default Sidebar;