// Header.js
import React from 'react';

const Header = () => {
  return (
    <div style={{ height: '50px', background: '#333', color: '#fff', textAlign: 'center', lineHeight: '50px', position: 'fixed', top: 0, width: '100%'  }}>
        {/* <div style={{ height: '50px', background: '#333', color: '#fff', textAlign: 'center', lineHeight: '50px', position: 'fixed', bottom: 0, width: '100%' }}> */}

      Collaboration Hub
    </div>
  );
};

export default Header;
