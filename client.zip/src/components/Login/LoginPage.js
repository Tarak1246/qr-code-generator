import React, { useState } from 'react';
import './LoginPage.css';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { loginUser, registerUser } from '../../services/api';
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import QrCode from '../../pages/Home/qr-code.png';

const LoginPage = () => {
    toast.configure();
    const {
        reset,
        register,
        handleSubmit,
        setError,
        clearErrors,
        formState: { errors },
        watch
    } = useForm({});

    const [token, setToken] = useState(localStorage.getItem('token') || '');
    const navigate = useNavigate();
    let password = watch("password");
    const [login, setlogin] = useState(true);
    let userData = "";

    const onSubmit = async (data) => {
        navigate('/home');
        // try {
        //     login ? userData = await loginUser(data) : userData = await registerUser(data);
        //     if (userData?.status == 200) {
        //         setToken(userData.token);
        //         toast.success(userData.data, {
        //             position: toast.POSITION.TOP_RIGHT,
        //             autoClose: 10000
        //         });
        //         localStorage.setItem('token', token);
        //     } else {
        //         toast.error(userData.data, {
        //             position: toast.POSITION.TOP_RIGHT,
        //             autoClose: 10000
        //         });
        //     }
        // } catch (error) {
        //     console.log(error);
        //     toast.error(`Request failed. Please try again.`, {
        //         position: toast.POSITION.TOP_RIGHT,
        //         autoClose: 20000
        //     });
        // } finally {
        //     reset();
        // }
    };


    return (
        <div>
            <div className='rowA'>
                {/* <img src={QrCode} alt="qr code" /> */}
            </div>
            <div className='rowB' style={!login ? { marginTop: 10 } : {}}>
                <h2>{login ? 'Login' : 'Register'}</h2>
                {login ?
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div className="form-control f-c1" >
                            <label>Username</label>
                            <input type="text" style={{
                                borderWidth: 1,
                                borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 300,
                                height: 50,
                                backgroundColor: '#fff',
                                borderRadius: 10,
                            }} name="username" {...register("username", {
                                required: "username is required."
                            })} autoComplete='off' />
                            {errors.username && <p className="errorMsg">{errors.username.message}</p>}
                        </div>
                        <div className="form-control">
                            <label>Password</label>
                            <input type="password" style={{
                                borderWidth: 1,
                                borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 300,
                                height: 50,
                                backgroundColor: '#fff',
                                borderRadius: 10
                            }} name="password" {...register("password", {
                                required: true,
                                validate: {
                                    checkLength: (value) => value.length >= 6,
                                    matchPattern: (value) =>
                                        /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)(?=.*[!@#$*])/.test(
                                            value
                                        )
                                }
                            })} />
                            {errors.password?.type === "required" && (
                                <p className="errorMsg">Password is required.</p>
                            )}
                            {errors.password?.type === "checkLength" && (
                                <p className="errorMsg">
                                    Password should be at-least 6 characters.
                                </p>
                            )}
                            {errors.password?.type === "matchPattern" && (
                                <p className="errorMsg">
                                    Password should contain at least one uppercase letter, lowercase
                                    letter, digit, and special symbol.
                                </p>
                            )}
                        </div>
                        <p id="logintxt">Don't have an account? <Link><span onClick={() => { setlogin(false); clearErrors(["email", "password"]); reset(); }}>register</span></Link></p>
                        {errors.apiError && <p>{errors.apiError.message}</p>}
                        <div className="form-control">
                            <button style={{
                                borderWidth: 1,
                                // borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 100,
                                height: 50,
                                // color: 'violet',
                                borderRadius: 40
                            }} type="submit" disabled={Object.keys(errors).length > 0}>Login</button>
                        </div>
                    </form>
                    :
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div className="form-control f-c1" >
                            <label>Username</label>
                            <input type="text" style={{
                                borderWidth: 1,
                                borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 300,
                                height: 50,
                                backgroundColor: '#fff',
                                borderRadius: 10,
                            }} name="username" {...register("username", {
                                required: "username is required."
                            })} autoComplete='off' />
                            {errors.username && <p className="errorMsg">{errors.username.message}</p>}
                        </div>
                        <div className="form-control f-c1" >
                            <label>Email</label>
                            <input type="text" style={{
                                borderWidth: 1,
                                borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 300,
                                height: 50,
                                backgroundColor: '#fff',
                                borderRadius: 10,
                            }} name="email" {...register("email", {
                                required: "Email is required.",
                                pattern: {
                                    value: /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
                                    message: "Email is not valid."
                                }
                            })} autoComplete='off' />
                            {errors.email && <p className="errorMsg">{errors.email.message}</p>}
                        </div>
                        <div className="form-control">
                            <label>Password</label>
                            <input type="password" style={{
                                borderWidth: 1,
                                borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 300,
                                height: 50,
                                backgroundColor: '#fff',
                                borderRadius: 10
                            }} name="password" {...register("password", {
                                required: true,
                                validate: {
                                    checkLength: (value) => value.length >= 6,
                                    matchPattern: (value) =>
                                        /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)(?=.*[!@#$*])/.test(
                                            value
                                        )
                                }
                            })} />
                            {errors.password?.type === "required" && (
                                <p className="errorMsg">Password is required.</p>
                            )}
                            {errors.password?.type === "checkLength" && (
                                <p className="errorMsg">
                                    Password should be at-least 6 characters.
                                </p>
                            )}
                            {errors.password?.type === "matchPattern" && (
                                <p className="errorMsg">
                                    Password should contain at least one uppercase letter, lowercase
                                    letter, digit, and special symbol.
                                </p>
                            )}
                        </div>
                        <div className="form-control">
                            <label>Confirm Password</label>
                            <input type="password" style={{
                                borderWidth: 1,
                                borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 300,
                                height: 50,
                                backgroundColor: '#fff',
                                borderRadius: 10
                            }} name="confirm_password" {...register("confirm_password", {
                                required: true,
                                validate: value => value === password || "The passwords do not match"
                            })} />
                            {errors.confirm_password && <p className="errorMsg">{errors.confirm_password.message}</p>}
                        </div>
                        {errors.apiError && <p>{errors.apiError.message}</p>}
                        <p id="registertxt">Already have an Account , Want to <Link><span onClick={() => { setlogin(true); clearErrors(["username", "email", "password", "confirm_password"]); reset(); }}>login</span></Link></p>
                        <div className="form-control">
                            <button style={{
                                borderWidth: 1,
                                // borderColor: 'violet',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 100,
                                height: 50,
                                // color: 'violet',
                                borderRadius: 40
                            }} type="submit" disabled={Object.keys(errors).length > 0}>Register</button>
                        </div>
                    </form>
                }
            </div>
        </div>

    );
};

export default LoginPage;






/*import React, { useState } from 'react';
import './style.css';
import axios from 'axios';

const RegistrationForm = () => {
    const [imageData, setImageData] = useState('');
    const [formData, setFormData] = useState({
        firstName: {
            "name": "",
            "label": "",
            "value": "",
            "type": ""
        },
        lastName: {
            "name": "",
            "label": "",
            "value": "",
            "type": ""
        },
        email: {
            "name": "",
            "label": "",
            "value": "",
            "type": ""
        },
        password: {
            "name": "",
            "label": "",
            "value": "",
            "type": ""
        }
    });

    const handleChange = (e) => {
        const { name, value, type, placeholder } = e.target;
        console.log(formData);
        console.log(e.target)
        setFormData({
            ...formData, [name]: {
                "name": name,
                "label": placeholder,
                "value": value,
                "type": type
            }
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        let requestObject = { "userid": "10", "data": formData };
        try {
            const response = await axios.post('http://localhost:3001/submit-form', { ...requestObject });
            console.log('http://localhost:3001' + response.data.url);
            setImageData('http://localhost:3001' + response.data.url);
        } catch (error) {
            console.error('Error submitting form:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="form-body">
                <div className="firstName">
                    <label className="form__label" htmlFor="firstName">First Name </label>
                    <input className="form__input" type="text" name="firstName" value={formData.firstName.value} onChange={handleChange} id="firstName" placeholder="First Name" />
                </div>
                <div className="lastName">
                    <label className="form__label" htmlFor="lastName">Last Name </label>
                    <input type="text" id="lastName" name="lastName" value={formData.lastName.value} className="form__input" onChange={handleChange} placeholder="Last Name" />
                </div>
                <div className="email">
                    <label className="form__label" htmlFor="email">Email </label>
                    <input type="email" id="email" name="email" className="form__input" value={formData.email.value} onChange={handleChange} placeholder="Email" />
                </div>
                <div className="password">
                    <label className="form__label" htmlFor="password">Password </label>
                    <input className="form__input" type="password" name="password" id="password" value={formData.password.value} onChange={handleChange} placeholder="Password" />
                </div>
            </div>
            <button type="submit" className="btn">Submit</button>
            <div>
                {imageData && <img src={imageData} alt="qr-code" />}
            </div>
        </form>
    )
}

export default RegistrationForm
*/