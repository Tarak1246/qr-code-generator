// Footer.js
import React from 'react';

const Footer = () => {
  return (
    <div style={{ height: '50px', background: '#333', color: '#fff', textAlign: 'center', lineHeight: '50px', position: 'fixed', bottom: 0, width: '100%' }}>
    {/* <div> */}
      @CodeCrafters
    </div>
  );
};

export default Footer;
