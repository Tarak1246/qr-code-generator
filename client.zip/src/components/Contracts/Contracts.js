// EditPage.js
import React, { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
// import { useForm, Controller } from 'react-hook-form';
import './Contracts.css';
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// import { useAsyncDebounce } from 'react-table';
// import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';
// import { getContracts } from '../../services/api';
import { useData } from '../DataContext';
import ConfirmToast from '../ConfirmToast/ConfirmToast';
// import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// import Dashboard from '../Dashboard/Dashboard';
// import Contracts from '../Contracts/Contracts';

const Contracts = () => {
  toast.configure();
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const { state, setDataa } = useData();

  useEffect(() => {
    const fetchData = async () => {
      try {
        // const response = await getContracts();
        let response = {
          "data": [
            {
              "id": 1,
              "name": "John Doe",
              "age": 30,
              "email": "john@example.com"
            },
            {
              "id": 2,
              "name": "Jane Smith",
              "age": 25,
              "email": "jane@example.com"
            },
          ]
        };
        setData(response.data); // Assuming the response is an array of data
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData(); // Call the function on component mount
  }, []); // The empty dependency array ensures it runs only once on mount

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  // Filtering data based on the search term
  const filteredData = data.filter((item) =>
    // item.name.toLowerCase().includes(searchTerm.toLowerCase())
    // Check if any property contains the search term
    Object.values(item).some((value) =>
      String(value).toLowerCase().includes(searchTerm)
    )
  );

  // Dynamic headers based on keys of the first item in data
  const tableHeaders = data.length > 0 ? Object.keys(data[0]) : [];

  const handleDeleteClick = () => {
    let toastId; // Declare toastId variable

    const handleConfirm = () => {
      // Handle the delete action here
      console.log('Item deleted!');
      toast.success('Item deleted!', {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 10000
      });
      toast.dismiss(toastId); // Close the confirmation toast
      navigate('/home');
    };

    // Show confirmation toast and capture toastId
    toastId = toast.warning(<ConfirmToast onConfirm={handleConfirm} />, {
      autoClose: false,
      closeButton: true,
    });
  };


  const handleConfirm = () => {
    // Handle the delete action here
    console.log('Item deleted!');
    toast.success('Item deleted successfully!');
  };

  const handleDelete = async (id) => {
    toast(<ConfirmToast onConfirm={handleConfirm} />, {
      autoClose: false,
      closeButton: true,
      // position: toast.POSITION.TOP_CENTER
    });
    // const shouldDelete = window.confirm('Are you sure you want to delete this item?');

    // if (shouldDelete) {
    //   try {
    //     // Make DELETE request to delete item from the database
    //     // await axios.delete(`your-api-endpoint/${id}`);
    //     // Update the local state (remove the deleted item)
    const updatedData = data.filter((item) => item.id !== id);
    setData(updatedData);
    //     // navigate('/home')
    //   } catch (error) {
    //     console.error('Error deleting item:', error);
    //   }
    // }
  };

  const handleEditClick = (item) => {
    console.log(item)
    // Call the provided callback to handle the edit button click
    // onEditButtonClick();
    setDataa(item);
    // Navigate to the edit page
    navigate(`/editContract/${item.id}`);

  };
  
  const addContract = async (e) => {
    try {
      navigate('/addContract');
    } catch (error) {
      console.error('Error cancelling contract:', error);
    }
  };

  return (
    <div>
      {/* <div className="my-component-container"> */}
        {/* <h1>{selectedTab.charAt(0).toUpperCase() + selectedTab.slice(1)}</h1> */}
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={handleSearch}
          className="search-input"
          style={{ float: 'left' }}
        />
        <button className="btn btn-primary" title="add a contract" onClick={() => addContract()}>
          ADD
        </button>
        {/* <table className="data-table">
        <thead>
          <tr>
            {Object.keys(data[0] || {}).map((header) => (
              <th key={header}>{header}</th>
            ))}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((item) => (
            <tr key={item.id}>
              {Object.keys(item).map((header) => (
                <td key={header}>{item[header]}</td>
              ))}
              <td>
                <Link to={`/edit/${item.id}`}>Edit</Link>
                <button onClick={() => handleDelete(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table> */}
        <table className="data-table">
          <thead>
            <tr>
              {tableHeaders.map((header) => (
                <th key={header}>{header.toUpperCase()}</th>
              ))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item) => (
              <tr key={item.id}>
                {tableHeaders.map((header) => (
                  <td key={header}>{item[header]}</td>
                ))}
                <td>
                  <button className="actionBtn" onClick={() => handleEditClick(item)}>Edit</button>
                  {/* <Link to={{ pathname: '/edit', state: { data: item } }}>Edit</Link> */}
                  {/* <Link to={`/edit/${item.id}`}>Edit</Link> */}
                  <button className="actionBtn" onClick={() => handleDeleteClick(item)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* <table className="data-table">
        <thead>
          <tr>
            {tableHeaders.map((header) => (
              <th key={header}>{header.toUpperCase()}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filteredData.map((item) => (
            <tr key={item.id}>
            {tableHeaders.map((header) => (
              <td key={header}>{item[header]}</td>
            ))}
          </tr>
          ))}
        </tbody>
      </table> */}
      {/* </div> */}
    </div>
  );
};

export default Contracts;
