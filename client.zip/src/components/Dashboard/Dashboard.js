import React from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {CategoryScale} from 'chart.js'; 
import Chart from 'chart.js/auto';


import './Dashboard.css'; // Import or create a stylesheet

const Dashboard = () => {
  Chart.register(CategoryScale);
  // Sample data (replace with your actual data)
  const projectData = {
    labels: ['Project A', 'Project B', 'Project C'],
    datasets: [
      {
        label: 'Number of Tasks',
        data: [10, 15, 8],
        backgroundColor: ['rgba(75,192,192,0.6)', 'rgba(255,99,132,0.6)', 'rgba(255,205,86,0.6)'],
      },
    ],
  };

  const contractData = {
    labels: ['Contract X', 'Contract Y', 'Contract Z'],
    datasets: [
      {
        data: [30, 20, 15],
        backgroundColor: ['rgba(75,192,192,0.6)', 'rgba(255,99,132,0.6)', 'rgba(255,205,86,0.6)'],
      },
    ],
  };

  const employeeData = {
    labels: ['Engineers', 'Designers', 'Managers'],
    datasets: [
      {
        data: [40, 25, 15],
        backgroundColor: ['rgba(75,192,192,0.6)', 'rgba(255,99,132,0.6)', 'rgba(255,205,86,0.6)'],
      },
    ],
  };
  const chartOptions = {
    plugins: {
      legend: {
        display: false,
        position: 'bottom', // Display legend on the right side
      },
    },
  };
  const chartOptions1 = {
    scales: {
      x: {
        stacked: false, // Set to true for a stacked bar chart
        grid: {
          display: false, // Show/hide the x-axis grid lines
        },
      },
      y: {
        stacked: false,
        beginAtZero: true,
        grid: {
          color: 'rgba(0,0,0,0.1)', // Color of the y-axis grid lines
        },
        ticks: {
          stepSize: 5, // Set the step size for the y-axis ticks
        },
      },
    },
    plugins: {
      legend: {
        display: true,
        position: 'top', // Display legend on the top
        labels: {
          usePointStyle: true, // Use point-style (shape) in legend labels
        },
      },
      title: {
        display: true,
        text: 'Bar Chart Example', // Title for the chart
        font: {
          size: 18, // Font size for the title
        },
      },
    },
    layout: {
      padding: {
        left: 10,
        right: 10,
        top: 10,
        bottom: 10,
      },
    },
    responsive: true,
    maintainAspectRatio: false, // Set to true to maintain aspect ratio
  };

  return (
    <div className="dashboard-container">
      <div className="chart-container">
        <h2>Projects</h2>
        <Bar data={projectData} options={chartOptions} />
        <div className="chart-label">
          <p>Total: {projectData.datasets[0].data.reduce((acc, val) => acc + val, 0)}</p>
          {/* <p>Label: {projectData.labels.join(', ')}</p> */}
        </div>
      </div>

      <div className="chart-container">
        <h2>Contracts</h2>
        <Doughnut data={contractData} />
        <div className="chart-label">
          <p>Total: {contractData.datasets[0].data.reduce((acc, val) => acc + val, 0)}</p>
          {/* <p>Label: {contractData.labels.join(', ')}</p> */}
        </div>
      </div>

      <div className="chart-container">
        <h2>Employee</h2>
        <Doughnut data={employeeData} />
        <div className="chart-label">
          <p>Total: {employeeData.datasets[0].data.reduce((acc, val) => acc + val, 0)}</p>
          {/* <p>Label: {employeeData.labels.join(', ')}</p> */}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
