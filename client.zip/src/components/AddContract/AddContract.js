// EditPage.js
import React, { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useForm, Controller } from 'react-hook-form';
import './AddContract.css';
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useAsyncDebounce } from 'react-table';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const AddContract = () => {
  toast.configure();
  const [formData, setFormData] = useState({});
  const {
    reset,
    register,
    handleSubmit,
    setError,
    clearErrors,
    control,
    formState: { errors }
  } = useForm({});

  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const navigate = useNavigate();
  const [login, setlogin] = useState(true);
  let userData = "";

  const cancelForm = async (e) => {
    try {
      // Make PUT request to update item in the database
      // await axios.put(`your-api-endpoint/${id}`, formData);
      // Redirect or navigate back to the main page after successful update
      // You can use a library like react-router-dom for navigation
      navigate('/home');
    } catch (error) {
      console.error('Error cancelling contract:', error);
    }
  };
  const onSubmit = async (data) => {
    console.log(data);
    navigate('/home');
    // try {
    //     login ? userData = await loginUser(data) : userData = await registerUser(data);
    //     if (userData?.status == 200) {
    //         setToken(userData.token);
    //         toast.success(userData.data, {
    //             position: toast.POSITION.TOP_RIGHT,
    //             autoClose: 10000
    //         });
    //         localStorage.setItem('token', token);
    //     } else {
    //         toast.error(userData.data, {
    //             position: toast.POSITION.TOP_RIGHT,
    //             autoClose: 10000
    //         });
    //     }
    // } catch (error) {
    //     console.log(error);
    //     toast.error(`Request failed. Please try again.`, {
    //         position: toast.POSITION.TOP_RIGHT,
    //         autoClose: 20000
    //     });
    // } finally {
    //     reset();
    // }
  };

  return (
    <div>
      <h3>Add Contract</h3>
      {/* <form className="dynamic-form" onSubmit={handleSubmit(onSubmit)}>
        <div className="form-group">
          <label>Registration Number</label>
          <input type="text" id="registrationNumber" name="registrationNumber" {...register("registrationNumber", {
            required: "registrationNumber is required."
          })} autoComplete='off' />
          {errors.registrationNumber && <p className="errorMsg">{errors.registrationNumber.message}</p>}
        </div>
        <div className="form-group">
          <label>Institution</label>
          <input type="text" id="institution" name="institution" {...register("institution", {
            required: "Institution is required."
          })} autoComplete='off' />
          {errors.institution && <p className="errorMsg">{errors.institution.message}</p>}
        </div>
        <div className="form-group">
          <label>Client Number</label>
          <input type="text" id="clientNumber" name="clientNumber" {...register("clientNumber", {
            required: "client number is required."
          })} autoComplete='off' />
          {errors.clientNumber && <p className="errorMsg">{errors.clientNumber.message}</p>}
        </div>
        <div className="form-group">
          <label>Conclusion Date</label>
          <DatePicker
            id="conclusionDate"
            name="conclusionDate"
            {...register('conclusionDate', {
              required: 'Conclusion Date is required.',
            })}
            dateFormat="yyyy-MM-dd"
            placeholderText="Select date"
            className="custom-datepicker"
          />
          {errors.conclusionDate && <p className="errorMsg">{errors.conclusionDate.message}</p>}
        </div>
        <div className="form-group">
          <label>Validity Date</label>
          <DatePicker
            id="validityDate"
            name="validityDate"
            {...register('validityDate', {
              required: 'Validation Date is required.',
            })}
            dateFormat="yyyy-MM-dd"
            placeholderText="Select date"
            className="custom-datepicker"
          />
          {errors.validityDate && <p className="errorMsg">{errors.validityDate.message}</p>}
        </div>
        <div className="form-group">
          <label>Termination Date</label>
          <DatePicker
            id="terminationDate"
            name="terminationDate"
            {...register('terminationDate', {
              required: 'Termination Date is required.',
            })}
            dateFormat="yyyy-MM-dd"
            placeholderText="Select date"
            className="custom-datepicker"
          />
          {errors.terminationDate && <p className="errorMsg">{errors.terminationDate.message}</p>}
        </div>
        <div className="form-group">
          <button type="submit" style={{
            borderWidth: 1,
            alignItems: 'center',
            justifyContent: 'center',
            width: 100,
            height: 50,
            color: 'black',
            borderRadius: 40
          }}>
            Submit
          </button>
          <button style={{
            borderWidth: 1,
            alignItems: 'center',
            justifyContent: 'center',
            width: 100,
            height: 50,
            color: 'black',
            borderRadius: 40
          }} onClick={() => cancelForm()}>
            Cancel
          </button>
        </div>

      </form> */}
      <form className="dynamic-form" onSubmit={handleSubmit(onSubmit)}>
        <div className="form-group">
          <label>Registration Number</label>
          <Controller
            name="registrationNumber"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <>
                <input type="text" {...field} autoComplete="off" />
                {errors.registrationNumber && <p className="errorMsg">{errors.registrationNumber.message}</p>}
              </>
            )}
            rules={{ required: 'Registration Number is required.' }}
          />
        </div>

        <div className="form-group">
          <label>Institution</label>
          <Controller
            name="institution"
            control={control}
            render={({ field }) => (
              <>
                <input type="text" {...field} autoComplete="off" />
                {errors.institution && <p className="errorMsg">{errors.institution.message}</p>}
              </>
            )}
            rules={{ required: 'Institution is required.' }}
          />
        </div>

        <div className="form-group">
          <label>Client Number</label>
          <Controller
            name="clientNumber"
            control={control}
            render={({ field }) => (
              <>
                <input type="text" {...field} autoComplete="off" />
                {errors.clientNumber && <p className="errorMsg">{errors.clientNumber.message}</p>}
              </>
            )}
            rules={{ required: 'client number is required.' }}
          />
        </div>

        <div className="form-group">
          <label>Conclusion Date</label>
          <Controller
            name="conclusionDate"
            control={control}
            render={({ field }) => (
              <>
                <DatePicker
                  {...field}
                  selected={field.value}
                  dateFormat="MM-dd-yyyy"
                  placeholderText="Select date"
                  className="custom-datepicker"
                  showMonthDropdown
                  showYearDropdown yearDropdownItemNumber={100}
                />
                {errors.conclusionDate && <p className="errorMsg">{errors.conclusionDate.message}</p>}
              </>
            )}
            rules={{ required: 'Conclusion Date is required.' }}
          />
        </div>

        <div className="form-group">
          <label>Validity Date</label>
          <Controller
            name="validityDate"
            control={control}
            render={({ field }) => (
              <>
                <DatePicker
                  {...field}
                  selected={field.value}
                  dateFormat="MM-dd-yyyy"
                  placeholderText="Select date"
                  className="custom-datepicker"
                  showMonthDropdown
                  showYearDropdown yearDropdownItemNumber={100}
                />
                {errors.validityDate && <p className="errorMsg">{errors.validityDate.message}</p>}
              </>
            )}
            rules={{ required: 'Validation Date is required.' }}
          />
        </div>

        <div className="form-group">
          <label>Termination Date</label>
          <Controller
            name="terminationDate"
            control={control}
            render={({ field }) => (
              <>
                <DatePicker
                  {...field}
                  selected={field.value}
                  dateFormat="MM-dd-yyyy"
                  placeholderText="Select date"
                  className="custom-datepicker"
                  showMonthDropdown
                  showYearDropdown yearDropdownItemNumber={100}
                />
                {errors.terminationDate && <p className="errorMsg">{errors.terminationDate.message}</p>}
              </>
            )}
            rules={{ required: 'Termination Date is required.' }}
          />
        </div>

        <div className="form-group">
          <button type="submit" style={{
            borderWidth: 1,
            alignItems: 'center',
            justifyContent: 'center',
            width: 100,
            height: 50,
            color: 'black',
            borderRadius: 40
          }}>
            Submit
          </button>
          <button style={{
            borderWidth: 1,
            alignItems: 'center',
            justifyContent: 'center',
            width: 100,
            height: 50,
            color: 'black',
            borderRadius: 40
          }} onClick={cancelForm}>
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddContract;
