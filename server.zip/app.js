const express = require('express');
const app = express();
const cors = require('cors');
const routes = require('./src/api/routes/index');
const { connectDB } = require('./src/database/index');
const morgan = require('morgan');
const errorHandlerMiddleware = require('./src/api/middlewares/errorHandlerMiddleware');
const authorizeMiddleware = require('./src/api/middlewares/authorizeMiddleware');
const variables = require("./config/variables.js");
const pino = require('pino');
const fs = require('fs');
// Connect to MongoDB
connectDB();

// Middleware for logging
app.use(morgan('dev'));

// Middleware for parsing JSON
app.use(express.json());

//cross origin requests handling
app.use(
	cors({
		credentials: true,
		methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
		origin: true,
	})
);

//allow requests from all servers
app.use((req, res, next) => {
	res.setHeader("Access-Control-Allow-Origin", "*");
	next();
});

// Create a writable stream to the log file
const logFile = fs.createWriteStream('./logs/logfile.log', { flags: 'a' });

// Create a pino logger with the writable stream as a destination
const logger = pino({ level: 'info' }, logFile);

// Middleware for logging incoming requests
app.use((req, res, next) => {
  // Log the incoming request
  logger.info({ req: req }, 'Incoming request');
  next();
});

// Routes
app.use('/', routes);

app.use('/v2/*', authorizeMiddleware);
// Error handling middleware
app.use(errorHandlerMiddleware);


// Middleware for logging responses
app.use((req, res, next) => {
  const originalEnd = res.end;

  res.end = function (chunk, encoding) {
    res.end = originalEnd;
    res.end(chunk, encoding);

    // Log the response
    logger.info({ res: res }, 'Response sent');
  };

  next();
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Additional error handling logic
});
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error.message);
  // Additional error handling logic
  process.exit(1); // Exit the process to prevent it from running indefinitely
});
// Start server
app.listen(variables.port, () => console.log("server started on port", variables.port, variables.env));



// const express = require('express');
// const bodyParser = require('body-parser');
// const qr = require('qr-image');
// const cors = require('cors');
// const mysql = require('mysql');
// const fs = require('fs');
// const ejs = require('ejs');
// const popup = require('alert');
// const app = express();
// const port = 3001;

// app.use(cors());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
// app.set('view engine', 'ejs');
// const db = mysql.createConnection({
//   host: '*.*.*.*',
//   user: '*',
//   password: '*',
//   database: '*',
// });
// db.connect((err) => {
//   if (err) {
//     console.error('Error connecting to MySQL:', err);
//     throw err;
//   } else {
//     console.log('Connected to MySQL database');
//   }
// });
// app.post('/submit-form', (req, res) => {
//   const formData = req.body;
//   let sql = `INSERT INTO qr_codes (id, data) VALUES (${formData.userid}, '${JSON.stringify(formData.data)}')`;
//   db.query(sql, (err, result) => {
//     if (err) console.log(err);
//     console.log("1 record inserted");
//     res.json({ "url": "/generate/" + formData.userid });
//   });
// });
// app.get('/generate/:id', (req, res) => {
//   let url = req.protocol + '://' + req.get('host') + "/getForm/" + req.params.id;
//   const qrCode = qr.image(url, { type: 'png' });
//   res.type('png');
//   qrCode.pipe(res);
// });
// app.get('/getForm/:id', (req, res) => {
//   const userid = req.params.id;
//   let sql = `SELECT * FROM qr_codes where id='${userid}'`;
//   console.log(sql);
//   db.query(sql, (err, result) => {
//     if (err) {
//       console.error('Error fetching form fields from MySQL:', err);
//       res.status(500).send('Internal Server Error');
//       return;
//     }
//     console.log(result[0].data);
//     console.log(Object.values(JSON.parse(result[0].data)));
//     const formFields = Object.values(JSON.parse(result[0].data));

//     res.render('index', { formFields });
//   });
// });
// app.post('/submit_form', (req, res) => {
//   let content;
//   const { userid, email, lastName, firstName } = req.body;
//   let sql = `INSERT INTO student_details (id, firstname, lastname, email) VALUES (${userid}, '${firstName}', '${lastName}', '${email}')`;
//   db.query(sql, (err, result) => {
//     console.log(err);
//     // content.log(result);
//     if (err) {
//       content = `
//         <!DOCTYPE html>
//         <html lang="en">
//         <head>
//           <meta charset="UTF-8">
//           <meta http-equiv="X-UA-Compatible" content="IE=edge">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Success Page</title>
//         </head>
//         <body>
//           <h1>Internal Server Error!</h1>
//           <p>Your operation was successful.</p>
//         </body>
//         </html>
//       `;
//     } else {
//       content = `
//         <!DOCTYPE html>
//         <html lang="en">
//         <head>
//           <meta charset="UTF-8">
//           <meta http-equiv="X-UA-Compatible" content="IE=edge">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Success Page</title>
//         </head>
//         <body>
//           <h1>Success!</h1>
//           <p>Your operation was successful.</p>
//         </body>
//         </html>
//       `;
//     }
//     // Send the HTML content as the response
//     res.send(content);
//   });
// });
// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// }); 
